<?php
session_start();
require_once "../model/sql_queries.php";

if(isset($_POST["register_submit"])) {
    //check if user exists
    $username = $_POST["username"];
    if (existsUser($username)) {
        //if yes - return error
        $exists = true;
        include "../view/register.php";
    } else {
        $email = $_POST["email"];
        $password = $_POST["password"];
        if (strlen(trim(htmlentities($username))) > 0 &&
            strlen(trim(htmlentities($email))) > 0 &&
            strlen(trim(htmlentities($password))) > 0
        ) {
            try {
                $id = insertUser($username, $email, $password);
                $_SESSION["user_id"] = $id;
                header("Location:../view/main.html");
            } catch (PDOException $e) {
                header("Location:../view/error.php");
            }
        }
    }
}
?>