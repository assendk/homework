<?php
session_start();
require_once "../model/sql_queries.php";
if(isset($_POST["submit"])){
    $user_id = $_SESSION["user_id"];

    $upload_time = microtime();
    $file_tmp_name = $_FILES["image"]["tmp_name"];
    $extension = mime_content_type($file_tmp_name);
    echo $extension;
    $extension = explode("/", $extension)[1];
    $file_new_name = "../uploads/$user_id-$upload_time.$extension";
    $file_url = "/uploads/$user_id-$upload_time.$extension";
    try{
        if(is_uploaded_file($file_tmp_name)){
            insertImage($file_url, $user_id);
            move_uploaded_file($file_tmp_name, $file_new_name);
            header("Location:../view/main.html");
        }
        else{
            header("Location:../view/error.html");
        }
    }
    catch (Exception $e){
        header("Location:../view/error.html");
    }
}
?>