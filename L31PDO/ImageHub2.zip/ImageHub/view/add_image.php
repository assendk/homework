<?php
session_start()
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add image</title>
</head>
<body>
<form action="../controller/add_image_controller.php" method="post" enctype="multipart/form-data">
    <input type="file" name="image"><br>
    <input type="submit" name="submit" value="Upload">
</form>
</body>
</html>