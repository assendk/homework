<?php
//constants
define('DB_IP', "192.168.8.22");
define('DB_PORT', "3306");
define('DB_USER', "ittstudent");
define('DB_PASS', "ittstudent-123");
define('DB_NAME', "imagehub");


function getConnection(){
    try{
        $pdo = new PDO("mysql:host=".DB_IP.":".DB_PORT.";dbname=".DB_NAME, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }
    catch (PDOException $e){
        echo "Ops! PDO Problem - " . $e->getMessage();
    }
}

/** Checks for successfull login with username and password
 * @param $username - the username from the login form
 * @param $password - the password from the login form
 * @return bool|mixed - the user if he exists or false if login not successful
 */
function existsUser($username, $password = null){
    try{
        $pdo = getConnection();
        $statement = $pdo->prepare("SELECT id, username, email, password FROM users WHERE username = ?");
        $statement->execute(array($username));
        if($password == null){
            return $statement->rowCount() > 0;
        }
        if($statement->rowCount() > 0){
            $user = $statement->fetch(PDO::FETCH_ASSOC);
            if($user["password"] == sha1($password)){
                return $user;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    catch (PDOException $e){
        header("Location:error.php");
    }
}

function getImagesForUser($owner_id, $page = 1){
    try{
        $pdo = getConnection();
        $statement = $pdo->prepare("SELECT image_url FROM images WHERE owner_id = ? LIMIT 1 OFFSET " . ($page-1));
        $statement->execute(array($owner_id));
        $urls = array();
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row){
            $urls[] = $row["image_url"];
        }
        return $urls;
    }
    catch (PDOException $e){
        echo $e->getMessage();
    }
}

function insertImage($image_url, $owner_id){
        $pdo = getConnection();
        $stm = $pdo->prepare("INSERT INTO images (image_url, owner_id) VALUES (?, ?)");
        $params = array($image_url, $owner_id);
        $stm->execute($params);
}

function insertUser($username, $email, $password){
    $pdo = getConnection();
    $statement = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $statement->execute(array($username, $email, sha1($password)));
    return $pdo->lastInsertId();
}
