<?php
ini_set('display_errors', 'on');

divide(0, 5);

function divide($a, $b){
    try {
        echo "start of try" . PHP_EOL;
        validateDigits($a, $b);
        echo "The result is " . ($a/$b) . PHP_EOL;
        echo "end of try" . PHP_EOL;
    }
    catch (Exception $e){
        echo "oops! Something was wrong - here is the reason: " . $e->getMessage();
        //file_put_contents("errors.log", $e->getMessage());
        throw $e;
    }

}

function validateDigits($a, $b){
    if($a == 0){
        throw new Exception("Sorry, the first number cannot be 0");
    }
    if($b == 0){
        throw new Exception("Sorry, you cannot divide by 0");
    }
}