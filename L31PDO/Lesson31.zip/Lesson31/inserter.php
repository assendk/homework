<?php
require_once 'dbmanager.php';
$success = false;
if(isset($_POST["submit"])){
    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    try{
        if(!$pdo->inTransaction()){
            $pdo->beginTransaction();
        }
        $stm = $pdo->prepare("INSERT INTO $dbname.mashini (name, age, gender) VALUES (?, ?, ?)");
        $params = array($name, $age, $gender);
        $stm->execute($params);
        $stm = $pdo->prepare("INSERT INT O $dbname.mashini (name, age, gender) VALUES (?, ?, ?)");
        $params = array($name."1", $age, $gender);
        $stm->execute($params);
        $success = true;
        $pdo->commit();
    }
    catch (PDOException $e){
        $pdo->rollBack();
        $success = $e->getMessage();
    }
}
?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="post">
        <input type="text" name="name" placeholder="name" maxlength="50" required><br>
        <input type="number" name="age" placeholder="age" required><br>
        <input type="text" name="gender" placeholder="gender" required><br>
        <input type="submit" name="submit" value="REGISTER"><br>

    </form>
    <?php
        if($success !== false){
            if($success === true){
                echo "<h3 style='background-color: green'>Success</h3>";
            }
            else{
                echo "<h3 style='background-color: red'>Fail - $success</h3>";
            }
        }
    ?>
</body>
</html>