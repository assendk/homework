<?php

$ip = "192.168.8.22";
$port = "3306";
$user = "ittstudent";
$pass = "ittstudent-123";
$dbname = "kozibg";
$pdo = null;
try{
    $pdo = new PDO("mysql:host=$ip:$port;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (PDOException $e){
    echo "Ops! PDO Problem - " . $e->getMessage();
}
