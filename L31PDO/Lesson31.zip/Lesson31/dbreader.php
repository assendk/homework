<?php

$ip = "192.168.8.22";
$port = "3306";
$user = "ittstudent";
$pass = "ittstudent-123";
$dbname = "kozibg";
try{
    $pdo = new PDO("mysql:host=$ip:$port;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $result = $pdo->query("SELECT name, age FROM $dbname.mashini");
    $result = $pdo->exec("INSERT INTO mashini (name, age) VALUES ('Ivan', 10)");
    echo "<table style='border: solid 1px black'>";
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
            echo "<td style='border: solid 1px black'>";
                echo $row["name"];
            echo "</td>";
            echo "<td style='border: solid 1px black'>";
                echo $row["age"];
            echo "</td>";
        echo "</tr>";

    }
    echo "</table>";
    echo "Bravo!";
}
catch (PDOException $e){
    echo "Ops! PDO Problem - " . $e->getMessage();
}
