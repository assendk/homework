<?php
/*
* Author : Ali Aboussebaba
* Email : bewebdeveloper@gmail.com
* Website : http://www.bewebdeveloper.com
* Subject : Using Ajax with PHP/MySQL
*/

include('config.php');
$pdo = connect();
// adding new member using PDO with try/catch to escape the exceptions
try {
	$sql = "INSERT INTO members (full_name, email, age) VALUES (:full_name, :email, :age)";
	$query = $pdo->prepare($sql);
	$query->bindParam(':full_name', $_POST['full_name'], PDO::PARAM_STR);
	$query->bindParam(':email', $_POST['email'], PDO::PARAM_STR);
	$query->bindParam(':age', $_POST['age'], PDO::PARAM_STR);
	$query->execute();
} catch (PDOException $e) {
	echo 'PDOException : '.  $e->getMessage();
}

// list_members : this file displays the list of members in a table view
include('list_members.php');
?>