<?php
/**
 * Created by PhpStorm.
 * User: assen.kovachev
 * Date: 4.10.2017 г.
 * Time: 14:43 ч.
 */

$temp = "test";
$res = sha1($temp);
echo $res;