<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
        <a href="login.php">Try again with a fresh login</a>
</body>
</html>