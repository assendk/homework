<?php
require_once "login.php";
?>
<div id="error_div" style="background-color: red">No such username or password</div>
