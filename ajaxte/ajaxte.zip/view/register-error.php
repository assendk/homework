<?php
require_once "register.php";
?>
<div id="error_div" style="background-color: red">Wrong password</div>
