<?php
/**
 * Created by PhpStorm.
 * User: assen.kovachev
 * Date: 24.8.2017 г.
 * Time: 15:53 ч.
 */
?>
<div id="footer">
    <h2>Footer content</h2>
</div>
</body>
</html>
