<?php
/**
 * Created by PhpStorm.
 * User: assen.kovachev
 * Date: 5.9.2017 г.
 * Time: 00:25 ч.
 */
?>
<div id="new-note">
    <form action="" method="post">
        Title:
        <input type="text" name="title"><br>
        Priority:
        <input type="radio" name="priority" value="1">1
        <input type="radio" name="priority" value="2">2
        <input type="radio" name="priority" value="3">3
        <input type="radio" name="priority" value="4">4
        <input type="radio" name="priority" value="5">5<br>
        Content:
        <textarea name="" id="" cols="30" rows="10"></textarea>
        <input type="submit" name="new-note" value="Add">
    </form>
</div>