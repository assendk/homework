<?php
?>
<div id="menu">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="register.php">Register</a></li>
        <li><a href="main.php">Notes</a></li>
    </ul>
</div>
